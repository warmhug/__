/**
@module ordered-list
*/

/**
编辑器的有序列表插件

### Commands
- insertOrderedList 对选区设置或取消为有序列表.支持 queryCommandValue，返回选区是否是有序列表
@class OrderedList 
*/