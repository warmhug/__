/**
@module eindent
*/

/**
编辑器的缩进插件

### Commands
- indent 对选区缩进
@class Indent
*/