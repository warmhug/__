/**
@module italic
*/

/**
编辑器的斜体插件

### Commands
- italic 对选区文字设置斜体或取消斜体,支持 queryCommandValue，返回当前路径是否是斜体覆盖
@class Italic
*/