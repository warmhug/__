/**
@module separator
*/

/**
编辑器的分隔符插件
@class Separator
*/