/**
@module strike-through
*/

/**
编辑器的字体删除线插件

### Commands
- strikeThrough 对选区文字删除线或取消.支持 queryCommandValue，返回当前路径是否被删除线覆盖
@class StrikeThrough
*/