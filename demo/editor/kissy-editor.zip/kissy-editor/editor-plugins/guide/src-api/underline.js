/**
@module underline
*/

/**
编辑器的字体下划线插件

### Commands
- underline 对选区文字下划线或取消.支持 queryCommandValue，返回当前路径是否被下划线覆盖
@class Underline
*/