/**
@module xiami-music
*/

/**
编辑器的虾米音乐插件
@class XiaMiMusic
*/