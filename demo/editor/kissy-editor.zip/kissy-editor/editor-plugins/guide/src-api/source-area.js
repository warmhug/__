/**
@module source-area
*/

/**
编辑器的源码按钮插件
@class SourceArea
*/