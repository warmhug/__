/**
@module outdent
*/

/**
编辑器的缩出插件

### Commands
- outdent 对选区缩出 支持 queryCommandValue，返回当前路径是否可以缩出
@class Outdent
*/