/**
@module remove-format
*/

/**
编辑器的清除格式插件

### Commands
- removeFormat 对选区清除格式.
@class RemoveFormat
*/