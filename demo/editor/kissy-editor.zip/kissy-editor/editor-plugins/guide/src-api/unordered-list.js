/**
@module unordered-list
*/

/**
编辑器的无序列表插件

### Commands
- insertUnorderedList 对选区设置为无序列表或取消.支持 queryCommandValue，返回当前路径是否是无序列表
@class UnorderedList
*/