/**
@module smiley
*/

/**
编辑器的表情插件
@class Smiley
*/