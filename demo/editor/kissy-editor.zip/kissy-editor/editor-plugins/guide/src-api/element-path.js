/**
@module element-path
*/

/**
编辑器的节点路径插件
### 推荐仅用于调试开发，不要给用户使用.
@class ElementPath
*/