/**
@module checkbox-source-area
*/

/**
编辑器的框选切换源码插件
```
KISSY.use('editor',function(S,Editor){
    S.use('kg/editor-plugins/当前版本号/checkbox-source-area',function(S,checkBoxSourceArea){
        // use
    });
});
```
@class CheckBoxSourceArea
*/