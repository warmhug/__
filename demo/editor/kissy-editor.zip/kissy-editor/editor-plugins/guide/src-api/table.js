/**
@module table
*/

/**
编辑器的表格插件
@class Table
*/