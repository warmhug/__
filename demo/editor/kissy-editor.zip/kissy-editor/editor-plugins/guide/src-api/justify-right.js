/**
@module justify-right
*/

/**
编辑器的居右对齐插件

### Commands
- justifyRight 对选区文字居右或取消.支持 queryCommandValue，返回选区是否居右
@class JustifyRight
*/