/**
@module page-break
*/

/**
编辑器的分页符插件
@class PageBreak
*/