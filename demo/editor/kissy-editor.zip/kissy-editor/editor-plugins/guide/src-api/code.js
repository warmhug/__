/**
@module code
*/

/**
编辑器的代码插件
@class Code
*/