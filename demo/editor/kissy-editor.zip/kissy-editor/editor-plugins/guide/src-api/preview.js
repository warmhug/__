/**
@module preview
*/

/**
编辑器的预览插件
@class Preview
*/