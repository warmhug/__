
http://gallery.kissyui.com/editor-plugins/doc/guide/api/classes/Image.html#attr_remote

http://gallery.kissyui.com/WKeditor/doc/guide/index.html

https://github.com/kissyteam/editor-plugins

http://gallery.kissyui.com/editor-plugins/doc/demo/index.html
